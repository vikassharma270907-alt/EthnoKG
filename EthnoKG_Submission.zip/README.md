# EthnoKG: Traditional Knowledge into Traceable Scientific Evidence

> **EthnoHack 2026 Submission**  
> AI-powered scientific literature mining and Knowledge Graph for traditional medicine and natural products discovery.

---

## 🌿 Overview

For centuries, empirical medicinal plant knowledge across diverse indigenous cultures has remained fragmented, unindexed, and difficult to cross-reference with modern pharmacology. 

**EthnoKG** bridges this gap:
- **12-Stage Literature Mining Engine:** Extracts botanical entities, vernacular synonyms, phytochemicals, preparation methods, and therapeutic applications from scientific literature.
- **Interactive Knowledge Graph:** Dynamic Cytoscape.js exploration of Plant → Compound → Target/Condition links.
- **6-Tier Evidence Classification:** Strictly distinguishes folkloric reports, in-vitro bioassays, in-vivo preclinical models, and clinical trials.
- **Human-in-the-Loop Verification:** Scientific curation portal to review, validate, or reject extracted claims with exact excerpt provenance.
- **Grounded Research Assistant:** Query ethnopharmacological relationships with citations and zero clinical hallucinations.

---

## 🚀 Quick Start

### 1. Backend (FastAPI + SQLite + NetworkX)
```bash
cd backend
python -m venv venv
# Windows:
.\venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
API Documentation will be live at: `http://localhost:8000/docs`

### 2. Frontend (React 19 + Vite + Tailwind CSS)
```bash
cd frontend
npm install
npm run dev
```
Open `http://localhost:5173` in your browser.

---

## 🛠️ Tech Stack
- **Frontend:** React 19, TypeScript, Vite, Tailwind CSS, Cytoscape.js, Recharts, Lucide Icons
- **Backend:** Python 3.14+, FastAPI, SQLAlchemy 2.0, Pydantic v2, NetworkX
- **Database:** SQLite (`ethno_kg.db`)
- **Evaluation & Testing:** Pytest, custom F1 evaluation test harness against gold-standard annotations

---

## ⚖️ Ethics & Nagoya Protocol
EthnoKG strictly preserves cultural attribution and complies with the Nagoya Protocol on Access and Benefit Sharing. It serves strictly as a scientific research and discovery platform, not medical diagnosis or treatment advice.

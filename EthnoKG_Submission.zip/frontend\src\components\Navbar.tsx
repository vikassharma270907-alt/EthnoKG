import React from 'react';
import { 
  Network, 
  Leaf, 
  BarChart3, 
  Search, 
  Database, 
  ShieldCheck, 
  Sparkles, 
  BookOpen, 
  FileText, 
  Globe2 
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  pendingCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, pendingCount = 0 }) => {
  const navItems = [
    { id: 'landing', label: 'Overview', icon: Globe2 },
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'extraction', label: 'Literature Mining', icon: Search },
    { id: 'plants', label: 'Plant Intelligence', icon: Leaf },
    { id: 'graph', label: 'Knowledge Graph', icon: Network },
    { id: 'evidence', label: 'Evidence Explorer', icon: Database },
    { id: 'assistant', label: 'Research Assistant', icon: Sparkles },
    { 
      id: 'verification', 
      label: 'Verification', 
      icon: ShieldCheck, 
      badge: pendingCount > 0 ? pendingCount : undefined 
    },
    { id: 'methodology', label: 'Methodology', icon: BookOpen },
    { id: 'sources', label: 'Sources & Ethics', icon: FileText },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#070c19]/90 backdrop-blur-md border-b border-slate-800/80 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Identity */}
          <div 
            onClick={() => setActiveTab('landing')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform duration-200">
              <Network className="w-6 h-6 text-slate-950 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight text-white font-mono">Ethno<span className="text-emerald-400">KG</span></span>
                <span className="text-[10px] font-semibold uppercase tracking-wider bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.5 rounded">
                  EthnoHack '26
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">Traceable Traditional Knowledge Discovery</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`relative flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 ${
                    isActive 
                      ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 shadow-sm shadow-emerald-500/10'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {item.badge !== undefined && (
                    <span className="ml-0.5 px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Quick CTA */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('extraction')}
              className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors shadow-md shadow-emerald-500/20 flex items-center gap-1.5"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Mine Literature</span>
            </button>
          </div>

        </div>
      </div>

      {/* Mobile navigation row */}
      <div className="lg:hidden flex overflow-x-auto py-2 px-4 border-t border-slate-800/60 gap-1.5 bg-[#070c19]">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`whitespace-nowrap flex items-center gap-1.5 px-2.5 py-1 rounded text-xs ${
                isActive 
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Icon className="w-3 h-3" />
              <span>{item.label}</span>
              {item.badge !== undefined && (
                <span className="ml-0.5 px-1 text-[9px] rounded-full bg-amber-500/30 text-amber-300">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </header>
  );
};
